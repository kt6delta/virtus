<?php
/**
 * Kunena Component
 *
 * @package         Kunena.Template.BlueEagle5
 * @subpackage      Layout.User
 *
 * @copyright   (C) 2008 - 2022 Kunena Team. All rights reserved.
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            https://www.kunena.org
 **/
defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

$this->config        = KunenaConfig::getInstance();
$me                  = KunenaUserHelper::getMyself();
$avatar              = $this->profile->getAvatarImage(KunenaFactory::getTemplate()->params->get('avatarType'), 'post');
$banInfo             = $this->config->showbannedreason
? KunenaUserBan::getInstanceByUserid($this->profile->userid)
	: null;
$private             = KunenaFactory::getPrivateMessaging();
$websiteURL          = $this->profile->getWebsiteURL();
$websiteName         = $this->profile->getWebsiteName();
$personalText        = $this->profile->getPersonalText();
$signature           = $this->profile->getSignature();

$activityIntegration = KunenaFactory::getActivityIntegration();
$points              = $activityIntegration->getUserPoints($this->profile->userid);
$medals              = $activityIntegration->getUserMedals($this->profile->userid);

if ($this->config->showuserstats)
{
	$showKarma = $this->config->showkarma;
	$rankImage = $this->profile->getRank(0, 'image');
	$rankTitle = $this->profile->getRank(0, 'title');
}
?>
<?php if ($avatar) : ?>
	<div class="kavatar-lg"><?php echo $avatar; ?></div>
	<?php if ($this->config->user_status) :?>
	<div class="center">
		<strong><?php echo $this->subLayout('User/Item/Status')->set('user', $this->profile); ?></strong>
	</div>
	<?php endif; ?>
<?php endif; ?>
<div id="kprofile-stats">
	<ul>
		<?php if (!empty($this->profile->banReason)) : ?>
			<li><strong><?php echo Text::_('COM_KUNENA_MYPROFILE_BANINFO'); ?>
				:</strong> <?php echo $this->profile->escape($this->profile->banReason); ?></li><?php endif ?>
		<?php if (!empty($this->profile->usertype)): ?>
			<li class="usertype"><?php echo Text::_($this->profile->usertype); ?></li><?php endif; ?>
		<?php if (!empty($this->profile->getRank(0, 'title'))): ?>
			<li><strong><?php echo Text::_('COM_KUNENA_MYPROFILE_RANK'); ?>
			: </strong><?php echo $this->profile->escape($this->profile->getRank(0, 'title')); ?></li><?php endif; ?>
		<?php if (!empty($this->profile->getRank(0, 'image'))): ?>
			<li class="kprofile-rank"><?php echo $this->profile->getRank(0, 'image'); ?></li><?php endif; ?>
		<?php if ($this->config->userlist_joindate || $me->isModerator()) : ?>
			<li>
				<strong> <?php echo Text::_('COM_KUNENA_MYPROFILE_REGISTERDATE'); ?>:</strong>
				<span title="<?php echo $this->profile->getRegisterDate()->toKunena('ago'); ?>"> <?php echo $this->profile->getRegisterDate()->toKunena('date_today', 'utc'); ?> </span>
			</li>
		<?php endif; ?>
		<?php if ($this->config->userlist_lastvisitdate || $me->isModerator()) : ?>
			<li>
				<strong> <?php echo Text::_('COM_KUNENA_MYPROFILE_LASTLOGIN'); ?>:</strong>
				<span title="<?php echo $this->profile->getLastVisitDate()->toKunena('ago'); ?>"> <?php echo $this->profile->getLastVisitDate()->toKunena('config_post_dateformat'); ?> </span>
			</li>
		<?php endif; ?>
		<li>
			<strong> <?php echo Text::_('COM_KUNENA_MYPROFILE_TIMEZONE'); ?>:</strong>
			<span> UTC <?php echo $this->profile->getTime()->toTimezone(); ?> </span>
		</li>
		<li>
			<strong> <?php echo Text::_('COM_KUNENA_MYPROFILE_LOCAL_TIME'); ?>:</strong>
			<span> <?php echo $this->profile->getTime()->toKunena('time'); ?> </span>
		</li>
		<?php if (!empty($this->profile->posts)): ?>
			<li><strong><?php echo Text::_('COM_KUNENA_MYPROFILE_POSTS'); ?>
				:</strong> <?php echo intval($this->profile->posts); ?></li><?php endif; ?>
		<?php if (!empty($this->profile->thankyou)): ?>
			<li>
			<strong><?php echo Text::_('COM_KUNENA_MYPROFILE_THANKYOU_RECEIVED'); ?></strong> <?php echo intval($this->profile->thankyou); ?>
			</li><?php endif; ?>
		<?php if (!empty($this->profile->userpoints)): ?>
			<li>
			<strong><?php echo Text::_('COM_KUNENA_AUP_POINTS'); ?></strong> <?php echo intval($this->profile->userpoints); ?>
			</li><?php endif; ?>
		<?php if (!empty($this->profile->usermedals)) : ?>
			<li><?php foreach ($this->profile->usermedals as $medal) : echo $medal, ' '; endforeach ?></li><?php endif ?>
		<li><strong><?php echo Text::_('COM_KUNENA_MYPROFILE_PROFILEVIEW'); ?>
				:</strong> <?php echo intval($this->profile->uhits); ?></li>
		<?php if (!empty($showKarma) && !empty($this->profile->karma) && $this->config->showkarma) : ?>
			<li>
				<strong> <?php echo Text::_('COM_KUNENA_KARMA'); ?>:</strong>
				<span> <?php echo Text::sprintf((int) $this->profile->karma); ?> </span>
			</li>
		<?php endif; ?>
		<?php if ($private) : ?>
			<?php echo $private->shownewIcon($this->profile->userid); ?>
		<?php endif; ?>
		<?php if ($this->candisplaymail) : ?>
			<a class="kbutton btn-small" href="mailto:<?php echo $this->profile->email; ?>"
			   rel="nofollow"><?php echo KunenaIcons::email(); ?></a>
		<?php endif; ?>
		<?php
		if (!empty($websiteName) && !empty($websiteURL))
			:
			?>
			<a class="kbutton btn-small" rel="nofollow noopener noreferrer" target="_blank"
			   href="<?php echo $websiteURL ?>"><?php echo KunenaIcons::globe() . ' ' . $websiteName; ?></a>
		<?php elseif (empty($websiteName) && !empty($websiteURL))
			:
			?>
			<a class="kbutton btn-small" rel="nofollow noopener noreferrer" target="_blank"
			   href="<?php echo $websiteURL ?>"><?php echo KunenaIcons::globe(); ?></a>
		<?php elseif (!empty($websiteName) && empty($websiteURL))
			:
			?>
			<button class="kbutton btn-small"><?php echo KunenaIcons::globe() . ' ' . $websiteName; ?></button>
		<?php endif; ?>
		<?php if (!empty($this->profile->personalText)) { ?>
			<li><strong><?php echo Text::_('COM_KUNENA_MYPROFILE_ABOUTME'); ?>
				:</strong> <?php echo KunenaHtmlParser::parseText($this->profile->personalText); ?></li><?php } ?>
	</ul>
</div>

