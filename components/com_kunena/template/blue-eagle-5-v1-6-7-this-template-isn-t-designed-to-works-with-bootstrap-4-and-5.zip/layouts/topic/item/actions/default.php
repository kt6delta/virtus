<?php
/**
 * Kunena Component
 *
 * @package         Kunena.Template.BlueEagle5
 * @subpackage      Layout.Topic
 *
 * @copyright   (C) 2008 - 2022 Kunena Team. All rights reserved.
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            https://www.kunena.org
 **/
defined('_JEXEC') or die;
// Goto up / down
?>
<td class="klist-actions-forum">
	<div class="kmessage-buttons-row">
		<?php echo $this->topicButtons->get('reply') ?>
		<?php echo $this->topicButtons->get('subscribe') ?>
		<?php echo $this->topicButtons->get('favorite') ?>
	</div>
	<div class="kmessage-buttons-row">
		<?php echo $this->topicButtons->get('delete') ?>
		<?php echo $this->topicButtons->get('undelete') ?>
		<?php echo $this->topicButtons->get('moderate') ?>
		<?php echo $this->topicButtons->get('sticky') ?>
		<?php echo $this->topicButtons->get('lock') ?>
	</div>
</td>
