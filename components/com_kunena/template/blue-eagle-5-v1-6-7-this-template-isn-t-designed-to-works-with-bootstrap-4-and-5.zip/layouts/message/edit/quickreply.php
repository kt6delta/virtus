<?php
/**
 * Kunena Component
 *
 * @package         Kunena.Template.BlueEagle5
 * @subpackage      Layout.Message
 *
 * @copyright   (C) 2008 - 2022 Kunena Team. All rights reserved.
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            https://www.kunena.org
 **/
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

$message = $this->message;

if (!$message->isAuthorised('reply'))
{
	return;
}


$author = isset($this->author) ? $this->author : $message->getAuthor();

$topic = isset($this->topic) ? $this->topic : $message->getTopic();

$category = isset($this->category) ? $this->category : $message->getCategory();

$config = isset($this->config) ? $this->config : KunenaFactory::getConfig();

$me = isset($this->me) ? $this->me : KunenaUserHelper::getMyself();

// Load caret.js always before atwho.js script and use it for autocomplete, emojiis...
$this->addStyleSheet('jquery.atwho.css');
$this->addScript('jquery.caret.js');
$this->addScript('jquery.atwho.js');

$this->addScriptOptions('com_kunena.kunena_topicicontype', '');
$this->addScriptOptions('com_kunena.kunena_quickreplymesid', $message->displayField('id'));

$this->addScript('edit.js');

if (KunenaFactory::getTemplate()->params->get('formRecover'))
{
	$this->addScript('sisyphus.js');
}

// Fixme: can't get the controller working on this
if ($me->canDoCaptcha() && KunenaConfig::getInstance()->quickreply)
{
	if (\Joomla\CMS\Plugin\PluginHelper::isEnabled('captcha'))
	{
		$plugin = \Joomla\CMS\Plugin\PluginHelper::getPlugin('captcha');
		$params = new \Joomla\Registry\Registry($plugin[0]->params);

		$captcha_pubkey = $params->get('public_key');
		$catcha_privkey = $params->get('private_key');

		if (!empty($captcha_pubkey) && !empty($catcha_privkey))
		{
			\Joomla\CMS\Plugin\PluginHelper::importPlugin('captcha');

			$result                    = Factory::getApplication()->triggerEvent('onInit', array('dynamic_recaptcha_' . $this->message->id));
			$output                    = Factory::getApplication()->triggerEvent('onDisplay', array(null, 'dynamic_recaptcha_' . $this->message->id,
				'class="controls g-recaptcha" data-sitekey="' . $captcha_pubkey . '" data-theme="light"',));
			$this->quickcaptchaDisplay = $output[0];
			$this->quickcaptchaEnabled = $result[0];
		}
	}
}
$template = KunenaTemplate::getInstance();
$quick    = $template->params->get('quick');
$editor   = $template->params->get('editor');
$message  = $this->message;
?>

<div id="kreply<?php echo intval($message->id) ?>_form" class="kreply-form" style="display: none">
	<form action="<?php echo KunenaRoute::_('index.php?option=com_kunena') ?>" method="post" name="postform"
	      enctype="multipart/form-data">
		<input type="hidden" name="view" value="topic"/>
		<input type="hidden" name="task" value="post"/>
		<input type="hidden" name="parentid" value="<?php echo intval($message->id) ?>"/>
		<input type="hidden" name="catid" value="<?php echo intval($category->id) ?>"/>
		<?php echo HTMLHelper::_('form.token') ?>

		<?php if ($me->exists() && $category->allow_anonymous): ?>
			<input type="text" name="authorname" size="35" class="kinputbox postinput" maxlength="35"
			       value="<?php echo $this->escape($author) ?>"/><br/>
			<input type="checkbox" id="kanonymous<?php echo intval($message->id) ?>" name="anonymous" value="1"
			       class="kinputbox postinput" <?php if ($category->post_anonymous) echo 'checked="checked"'; ?> />
			<label for="kanonymous<?php echo intval($message->id) ?>"><?php echo Text::_('COM_KUNENA_POST_AS_ANONYMOUS_DESC') ?></label>
			<br/>
		<?php else: ?>
			<input type="hidden" name="authorname" value="<?php echo $this->escape($me->name) ?>"/>
		<?php endif; ?>
		<?php if ($config->askemail && !KunenaFactory::getUser()->id): ?>
			<input type="text" id="email" name="email" size="35"
			       placeholder="<?php echo Text::_('COM_KUNENA_TOPIC_EDIT_PLACEHOLDER_EMAIL') ?>"
			       class="inputbox form-control"
			       maxlength="35" value="" required/>
			<?php echo $config->showemail == '0' ? Text::_('COM_KUNENA_POST_EMAIL_NEVER') : Text::_('COM_KUNENA_POST_EMAIL_REGISTERED'); ?>
		<?php endif; ?>
		<input type="text" name="subject" size="35" class="inputbox form-control"
		       maxlength="<?php echo $template->params->get('SubjectLengthMessage'); ?>"
		       value="<?php echo $this->escape($message->subject) ?>"/><br/>
		<?php if ($editor == 1)
		{
			echo $this->subLayout('Widget/Editor')->setLayout('wysibb_quick')->set('message', $this->message)->set('config', $config);
		}
		else
		{
			echo '<textarea class="span12 qreply qrlocalstorage' . $message->displayField("id") . ' id="editor" name="message" rows="6" cols="60" placeholder="' . Text::_('COM_KUNENA_ENTER_MESSAGE') . '"></textarea>';
		} ?>
		<br/>
		<input style="float: left; margin-right: 10px;" type="checkbox" name="subscribeMe" id="subscribeMe"
		       value="1" <?php if ($config->subscriptionschecked == 1 && $me->canSubscribe != 0 || $config->subscriptionschecked == 0 && $me->canSubscribe == 1 || $category->getSubscribed($me->userid))
		{
			echo 'checked="checked"';
		} ?> />
		<i><?php echo Text::_('COM_KUNENA_POST_NOTIFIED'); ?></i>
		<a href="index.php?option=com_kunena&view=topic&layout=reply&catid=<?php echo $message->catid; ?>&id=<?php echo $message->thread; ?>&mesid=<?php echo $message->id; ?>&Itemid=<?php echo KunenaRoute::getItemID(); ?>"
			   role="button" id="qrlocalstorage<?php echo $message->displayField('id'); ?>" class="btn btn-small btn-link pull-right gotoeditor"
			   rel="nofollow"><?php echo Text::_('COM_KUNENA_GO_TO_EDITOR'); ?></a>
		<br/>
		<?php if (!$config->allow_change_subject): ?>
			<input type="hidden" name="subject" value="<?php echo $this->escape($message->subject); ?>"/>
		<?php endif; ?>
		<?php if (!empty($this->quickcaptchaEnabled)) : ?>
			<div class="control-group">
				<?php echo $this->quickcaptchaDisplay; ?>
			</div>
		<?php endif; ?>
		<input type="submit" class="kbutton kreply-submit" name="submit"
		       value="<?php echo Text::_('COM_KUNENA_SUBMIT') ?>"
		       title="<?php echo(Text::_('COM_KUNENA_EDITOR_HELPLINE_SUBMIT')); ?>"/>
		<input type="reset" class="kbutton kreply-cancel" name="cancel"
		       data-related="kreply<?php echo $this->message->displayField('id'); ?>_form"
		       value="<?php echo Text::_('COM_KUNENA_CANCEL') ?>"
		       title="<?php echo(Text::_('COM_KUNENA_EDITOR_HELPLINE_CANCEL')); ?>"/>
		<small><?php echo Text::_('COM_KUNENA_QMESSAGE_NOTE') ?></small>
	</form>
</div>
