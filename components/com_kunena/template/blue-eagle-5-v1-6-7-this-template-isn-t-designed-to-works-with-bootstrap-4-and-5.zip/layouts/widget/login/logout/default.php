<?php
/**
 * Kunena Component
 *
 * @package         Kunena.Template.BlueEagle5
 * @subpackage      Layout.Widget
 *
 * @copyright   (C) 2008 - 2022 Kunena Team. All rights reserved.
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            https://www.kunena.org
 **/
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

function is_html(&$text) {
	if (strpos('<', $text) === FALSE)
	{
		return FALSE;
	}

	return TRUE;
}

function span_html($text, $class) {
	return '<span class="'.$class.'">'."${text}</span>";
}

function intrude_attention($text, $selection, $class) {
	$tag = span_html($selection, $class);
	return str_replace($selection, $tag, $text);
}

?>
<table class="kprofilebox">
	<tbody>
	<tr class="krow1">
		<?php if ($this->me->getAvatarImage('welcome')) : ?>
			<td class="kprofilebox-left">
				<?php echo $this->me->getAvatarImage(KunenaFactory::getTemplate()->params->get('avatarType'), 'welcome'); ?>
			</td>
		<?php endif; ?>
		<td class="kprofileboxcnt">
			<ul class="kprofilebox-link">
				<?php if (!empty($this->pm_link)) : ?>
					<li>
						<a href="<?php echo $this->pm_link; ?>" class="btn btn-link">
						<?php
							if ($this->inboxCountValue == 0)
							{
								echo $this->inboxCount;
							}
							elseif (is_html($this->inboxCount))
							{
								echo $this->inboxCount;
							}
							else
							{
								// selects attention to this link
								$pm_text = span_html( intrude_attention($this->inboxCount
										, $this->inboxCountValue
										, "kforce")
									, "kattention");
								echo $pm_text;
							}
							?>
						</a>
					</li>
				<?php endif ?>
				<?php if (!empty($this->profile_edit_url)) : ?>
					<li>
						<a href="<?php echo $this->profile_edit_url; ?>" class="btn btn-link">
							<?php echo Text::_('COM_KUNENA_LOGOUTMENU_LABEL_PREFERENCES'); ?>
						</a>
					</li>
				<?php endif ?>
				<?php if (!empty($this->announcementsUrl)) : ?>
					<li>
						<a href="<?php echo $this->announcementsUrl; ?>" class="btn btn-link">
							<?php echo Text::_('COM_KUNENA_ANN_ANNOUNCEMENTS') ?>
						</a>
					</li>
				<?php endif ?>
			</ul>
			<?php if ($this->plglogin): ?>

			<ul class="kprofilebox-welcome">
				<li>
					<?php echo Text::_('COM_KUNENA_PROFILEBOX_WELCOME'); ?>,
					<strong><?php echo $this->me->getLink() ?></strong>
				</li>
				<li class="kms">
					<strong><?php echo Text::_('COM_KUNENA_MYPROFILE_LASTLOGIN'); ?>:</strong>
					<span title="<?php echo KunenaDate::getInstance($this->me->lastvisitDate)->toKunena('ago'); ?>">
							<?php echo KunenaDate::getInstance($this->me->lastvisitDate)->toKunena('config_post_dateformat'); ?>
						</span>
				</li>
				<li>
					<form action="<?php echo KunenaRoute::_('index.php?option=com_kunena'); ?>" method="post"
					      id="logout-form" class="form-inline">
						<input type="hidden" name="view" value="user"/>
						<input type="hidden" name="task" value="logout"/>
						<?php echo HTMLHelper::_('form.token'); ?>
						<input type="submit" name="submit" class="kbutton"
						       value="<?php echo Text::_('COM_KUNENA_PROFILEBOX_LOGOUT'); ?>"/>
					</form>
				</li>
			</ul>
			<?php endif ?>
		</td>
		<!-- Module position -->
		<?php echo $this->subLayout('Widget/Module')->set('position', 'kunena_logout'); ?>
	</tr>
	</tbody>
</table>
