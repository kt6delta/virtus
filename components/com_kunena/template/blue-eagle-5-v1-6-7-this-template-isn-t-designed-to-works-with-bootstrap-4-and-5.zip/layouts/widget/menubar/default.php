<?php
/**
 * Kunena Component
 *
 * @package         Kunena.Template.BlueEagle5
 * @subpackage      Layout.Widget
 *
 * @copyright   (C) 2008 - 2022 Kunena Team. All rights reserved.
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            https://www.kunena.org
 **/
defined('_JEXEC') or die;
?>
<div id="ktop">
	<div id="ktopmenu">
		<div id="ktab">
			<?php echo $this->subRequest('Widget/Menu'); ?>
		</div>
	</div>
</div>
<div class="kblock kpbox">
	<div class="kcontainer" id="kprofilebox">
		<div class="kbody">
			<?php
			$config = KunenaFactory::getTemplate()->params;

			if ($config->get('displayModule'))
			{
				echo $this->subLayout('Widget/Module')->set('position', 'kunena_profilebox');
			}

			if ($config->get('displayProfileBox'))
			{
				if (KunenaUserHelper::getMyself()) :
					echo $this->subRequest('Widget/Login');
				else :
					echo $this->subRequest('Widget/Logout');
				endif;
			}
			?>
		</div>
	</div>
</div>
