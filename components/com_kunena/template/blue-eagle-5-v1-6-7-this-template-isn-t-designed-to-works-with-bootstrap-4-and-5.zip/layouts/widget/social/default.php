<?php
/**
 * Kunena Component
 *
 * @package         Kunena.Template.BlueEagle5
 * @subpackage      Layout.Widget
 *
 * @copyright   (C) 2008 - 2022 Kunena Team. All rights reserved.
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            https://www.kunena.org
 **/
defined('_JEXEC') or die;

if (KunenaUserHelper::getMyself()->socialshare == 0 && KunenaUserHelper::getMyself()->exists())
{
	return false;
}

$this->ktemplate = KunenaFactory::getTemplate();
$socialtheme     = $this->ktemplate->params->get('socialtheme');
$this->addStyleSheet('jssocials.css');
$this->addStyleSheet('jssocials-theme-' . $socialtheme . '.css');
$this->addScript('jssocials.js');
?>

<div id="share"></div>
