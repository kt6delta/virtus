# Template Layout Files

This directory contains all the template files used in Kunena HMVC.
