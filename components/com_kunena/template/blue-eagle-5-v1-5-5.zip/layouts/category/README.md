# Categories

Category views display various content from the categories.

Available layouts for the categories are:

* Category/Index - Displays category index.
* Category/Item - Displays a category with topics in it.
* Category/List - Displays flat list of categories (used for displaying subscriptions).
* Category/List/Row - Displays one category in a list.
* Category/Moderators - Displays list of moderators.
