<?php
/**
 * Kunena Component
 *
 * @package         Kunena.Template.BlueEagle5
 * @subpackage      Topic
 *
 * @copyright   (C) 2008 - 2020 Kunena Team. All rights reserved.
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            https://www.kunena.org
 **/
defined('_JEXEC') or die();

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;

HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('behavior.keepalive');

// Load scripts to handle fileupload process
Text::script('COM_KUNENA_UPLOADED_LABEL_INSERT_ALL_BUTTON');
Text::script('COM_KUNENA_EDITOR_INSERT');
Text::script('COM_KUNENA_EDITOR_IN_MESSAGE');
Text::script('COM_KUNENA_GEN_REMOVE_FILE');
Text::sprintf('COM_KUNENA_UPLOADED_LABEL_ERROR_REACHED_MAX_NUMBER_FILES', $this->config->attachment_limit, array('script' => true));
Text::script('COM_KUNENA_UPLOADED_LABEL_UPLOAD_BUTTON');
Text::script('COM_KUNENA_UPLOADED_LABEL_PROCESSING_BUTTON');
Text::script('COM_KUNENA_UPLOADED_LABEL_ABORT_BUTTON');
Text::script('COM_KUNENA_UPLOADED_LABEL_DRAG_AND_DROP_OR_BROWSE');
Text::script('COM_KUNENA_EDITOR_BOLD');
Text::script('COM_KUNENA_EDITOR_COLORS');
Text::script('COM_KUNENA_EDITOR_OLIST');
Text::script('COM_KUNENA_EDITOR_TABLE');
Text::script('COM_KUNENA_EDITOR_ITALIC');
Text::script('COM_KUNENA_EDITOR_UNDERL');
Text::script('COM_KUNENA_EDITOR_STRIKE');
Text::script('COM_KUNENA_EDITOR_SUB');
Text::script('COM_KUNENA_EDITOR_SUP');
Text::script('COM_KUNENA_EDITOR_CODE');
Text::script('COM_KUNENA_EDITOR_QUOTE');
Text::script('COM_KUNENA_EDITOR_SPOILER');
Text::script('COM_KUNENA_EDITOR_CONFIDENTIAL');
Text::script('COM_KUNENA_EDITOR_HIDE');
Text::script('COM_KUNENA_EDITOR_RIGHT');
Text::script('COM_KUNENA_EDITOR_LEFT');
Text::script('COM_KUNENA_EDITOR_CENTER');
Text::script('COM_KUNENA_EDITOR_HR');
Text::script('COM_KUNENA_EDITOR_FONTSIZE_SELECTION');
Text::script('COM_KUNENA_EDITOR_LINK');
Text::script('COM_KUNENA_EDITOR_EBAY');
Text::script('COM_KUNENA_EDITOR_MAP');
Text::script('COM_KUNENA_EDITOR_POLL_SETTINGS');
Text::script('COM_KUNENA_EDITOR_VIDEO');
Text::script('COM_KUNENA_EDITOR_VIDEO_PROVIDER');
Text::script('COM_KUNENA_EDITOR_IMAGELINK');
Text::script('COM_KUNENA_EDITOR_EMOTICONS');
Text::script('COM_KUNENA_EDITOR_TWEET');
Text::script('COM_KUNENA_EDITOR_INSTAGRAM');
Text::script('COM_KUNENA_EDITOR_SOUNDCLOUD');
Text::script('COM_KUNENA_EDITOR_COLOR_BLACK');
Text::script('COM_KUNENA_EDITOR_COLOR_ORANGE');
Text::script('COM_KUNENA_EDITOR_COLOR_RED');
Text::script('COM_KUNENA_EDITOR_COLOR_BLUE');
Text::script('COM_KUNENA_EDITOR_COLOR_PURPLE');
Text::script('COM_KUNENA_EDITOR_COLOR_GREEN');
Text::script('COM_KUNENA_EDITOR_COLOR_WHITE');
Text::script('COM_KUNENA_EDITOR_COLOR_GRAY');
Text::script('COM_KUNENA_EDITOR_ULIST');
Text::script('COM_KUNENA_EDITOR_LIST');
Text::script('COM_KUNENA_EDITOR_SIZE_VERY_VERY_SMALL');
Text::script('COM_KUNENA_EDITOR_SIZE_VERY_SMALL');
Text::script('COM_KUNENA_EDITOR_SIZE_SMALL');
Text::script('COM_KUNENA_EDITOR_SIZE_NORMAL');
Text::script('COM_KUNENA_EDITOR_SIZE_BIG');
Text::script('COM_KUNENA_EDITOR_SIZE_SUPER_BIGGER');

$this->addScriptOptions('com_kunena.imageheight', $this->config->imageheight);
$this->addScriptOptions('com_kunena.imagewidth', $this->config->imagewidth);

HTMLHelper::_('jquery.ui');
$this->addScript('assets/js/load-image.all.min.js');
$this->addScript('assets/js/canvas-to-blob.min.js');
$this->addScript('assets/js/jquery.iframe-transport.js');
$this->addScript('assets/js/jquery.fileupload.js');
$this->addScript('assets/js/jquery.fileupload-process.js');
$this->addScript('assets/js/jquery.fileupload-image.js');
$this->addScript('assets/js/jquery.fileupload-audio.js');
$this->addScript('assets/js/jquery.fileupload-video.js');
$this->addScript('assets/js/jquery.fileupload-validate.js');
$this->addScript('assets/js/upload.main.js');
$this->addStyleSheet('assets/css/fileupload.css');

$this->k = 0;

$this->addScriptOptions('com_kunena.kunena_upload_files_set_inline', KunenaRoute::_('index.php?option=com_kunena&view=topic&task=setinline&format=json&' . Session::getFormToken() . '=1', false));
$this->addScriptOptions('com_kunena.kunena_upload_files_rem', KunenaRoute::_('index.php?option=com_kunena&view=topic&task=removeattachments&format=json&' . Session::getFormToken() . '=1', false));
$this->addScriptOptions('com_kunena.kunena_upload_files_rem_inline_attachment', KunenaRoute::_('index.php?option=com_kunena&view=topic&task=removeinlineonattachment&format=json&' . Session::getFormToken() . '=1', false));
$this->addScriptOptions('com_kunena.kunena_upload_files_preload', KunenaRoute::_('index.php?option=com_kunena&view=topic&task=loadattachments&format=json&' . Session::getFormToken() . '=1', false));
$this->addScriptOptions('com_kunena.kunena_upload_files_maxfiles', $this->config->attachment_limit);
$this->addScriptOptions('com_kunena.icons.upload', KunenaIcons::upload());
$this->addScriptOptions('com_kunena.icons.trash', KunenaIcons::delete());
$this->addScriptOptions('com_kunena.icons.attach', KunenaIcons::attach());

// If polls are enabled, load also poll JavaScript.
$this->ktemplate = KunenaFactory::getTemplate();
$topicicontype   = $this->ktemplate->params->get('topicicontype');
$editor          = $this->ktemplate->params->get('editor');
$me              = isset($this->me) ? $this->me : KunenaUserHelper::getMyself();

if ($editor == 0)
{
	$this->addScript('assets/js/markitup.js');
	$this->addScript('assets/js/markitup.editor.js');
	$this->addScript('assets/js/markitup.set.js');
}

if ($this->config->pollenabled)
{
	Text::script('COM_KUNENA_POLL_OPTION_NAME');
	Text::script('COM_KUNENA_EDITOR_HELPLINE_OPTION');
	$this->addScript('assets/js/poll.js');
}

$this->addScript('assets/js/pollcheck.js');

$this->addScriptOptions('com_kunena.editor', $this->ktemplate->params->get('editor'));

$this->addScriptOptions('com_kunena.kunena_topicicontype', $topicicontype);

$this->addScriptOptions('com_kunena.allow_edit_poll', $this->config->allow_edit_poll);

$this->addScript('assets/js/edit.js');

echo $this->subLayout('Widget/Lightbox');

if (KunenaFactory::getTemplate()->params->get('formRecover'))
{
	$this->addScript('assets/js/sisyphus.js');
}
?>

	<div id="modal_confirm_template_category" class="modal hide fade" tabindex="-1" role="dialog"
	     aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3 id="myModalLabel"><?php echo Text::_('COM_KUNENA_MODAL_BOX_CATEGORY_TEMPLATE_TEXT_TITLE'); ?></h3>
		</div>
		<div class="modal-body">
			<p><?php echo Text::_('COM_KUNENA_MODAL_BOX_CATEGORY_TEMPLATE_TEXT_DESC'); ?></p>
		</div>
		<div class="modal-footer">
			<button class="kbutton" data-dismiss="modal"
			        aria-hidden="true"><?php echo Text::_('COM_KUNENA_MODAL_BOX_CATEGORY_TEMPLATE_TEXT_CLOSE'); ?></button>
			<button class="kbutton"
			        id="modal_confirm_erase"><?php echo Text::_('COM_KUNENA_MODAL_BOX_CATEGORY_TEMPLATE_TEXT_BUTTON_REPLACE'); ?></button>
			<button class="kbutton"
			        id="modal_confirm_erase_keep_old"><?php echo Text::_('COM_KUNENA_MODAL_BOX_CATEGORY_TEMPLATE_TEXT_BUTTON_REPLACE_KEEP'); ?></button>
		</div>
	</div>

	<form action="<?php echo KunenaRoute::_('index.php?option=com_kunena') ?>" method="post"
	      class="postform form-validate"
	      id="postform" name="postform" enctype="multipart/form-data" data-page-identifier="1" novalidate>
		<input type="hidden" name="view" value="topic"/>
		<input id="kurl_topicons_request" type="hidden"
		       value="<?php echo KunenaRoute::_('index.php?option=com_kunena&view=topic&layout=topicicons&format=raw', false); ?>"/>
		<input id="kurl_category_template_text" type="hidden"
		       value="<?php echo KunenaRoute::_('index.php?option=com_kunena&view=topic&layout=categorytemplatetext&format=raw', false); ?>"/>
		<input id="kcategory_poll" type="hidden" name="kcategory_poll" value="<?php echo $this->message->catid; ?>"/>
		<input id="kpreview_url" type="hidden" name="kpreview_url"
		       value="<?php echo KunenaRoute::_('index.php?option=com_kunena&view=topic&layout=edit&format=raw', false) ?>"/>
		<?php if (!$this->config->allow_change_subject)
			:
			?>
			<input type="hidden" name="subject" value="<?php echo $this->escape($this->message->subject); ?>"/>
		<?php endif; ?>
		<?php
		if ($this->message->exists())
			:
			?>
			<input type="hidden" name="task" value="edit"/>
			<input id="kmessageid" type="hidden" name="mesid" value="<?php echo intval($this->message->id) ?>"/>
		<?php else: ?>
			<input type="hidden" name="task" value="post"/>
			<input type="hidden" name="parentid" value="<?php echo intval($this->message->parent) ?>"/>
		<?php endif; ?>
		<?php if (!isset($this->selectcatlist)) : ?>
			<input type="hidden" name="catid" value="<?php echo intval($this->message->catid) ?>"/>
		<?php endif; ?>
		<?php if ($this->category->id && $this->category->id != $this->message->catid) : ?>
			<input type="hidden" name="return" value="<?php echo intval($this->category->id) ?>"/>
		<?php endif; ?>
		<?php if ($this->message->getTopic()->first_post_id == $this->message->id && $this->message->getTopic()->getPoll()->id) : ?>
			<input type="hidden" id="poll_exist_edit" name="poll_exist_edit"
			       value="<?php echo intval($this->message->getTopic()->getPoll()->id) ?>"/>
		<?php endif; ?>
		<input type="hidden" id="kunena_upload" name="kunena_upload"
		       value="<?php echo intval($this->message->catid) ?>"/>
		<input type="hidden" id="kunena_upload_files_url"
		       value="<?php echo KunenaRoute::_('index.php?option=com_kunena&view=topic&task=upload&format=json&' . Session::getFormToken() . '=1', false) ?>"/>
		<?php if ($this->me->exists())
			:
			?>
			<input type="hidden" id="kurl_users" name="kurl_users"
			       value="<?php echo KunenaRoute::_('index.php?option=com_kunena&view=user&layout=listmention&format=raw') ?>"/>
		<?php endif; ?>
		<?php echo HTMLHelper::_('form.token'); ?>

		<div class="kblock">
			<div class="kheader">
				<h2><span><?php echo $this->escape($this->headerText) ?></span></h2>
			</div>
			<div class="kcontainer">
				<div class="kbody">

					<table class="kblocktable<?php echo !empty ($this->category->class_sfx) ? ' kblocktable' . $this->escape($this->category->class_sfx) : '' ?>"
					       id="kpostmessage">
						<tbody id="kpost-message">
						<?php if (isset($this->selectcatlist)) : ?>
							<tr id="kpost-category" class="krow<?php echo 1 + $this->k ^= 1 ?>">
								<td class="kcol-first"><strong><?php echo Text::_('COM_KUNENA_CATEGORY') ?></strong>
								</td>
								<td class="kcol-mid"><?php echo $this->selectcatlist ?></td>
							</tr>
						<?php endif; ?>
						<?php if ($this->message->userid) : ?>
							<tr class="krow<?php echo 1 + $this->k ^= 1 ?>" id="kanynomous-check"
							    <?php if (!$this->category->allow_anonymous): ?>style="display:none;"<?php endif; ?>>
								<td class="kcol-first">
									<strong><?php echo Text::_('COM_KUNENA_POST_AS_ANONYMOUS'); ?></strong>
								</td>
								<td class="kcol-mid">
									<input type="checkbox" id="kanonymous" name="anonymous"
									       value="1" <?php if ($this->post_anonymous) echo 'checked="checked"'; ?> />
									<label for="kanonymous"><?php echo Text::_('COM_KUNENA_POST_AS_ANONYMOUS_DESC'); ?></label>
								</td>
							</tr>
						<?php endif; ?>
						<tr class="krow<?php echo 1 + $this->k ^= 1 ?>" id="kanynomous-check-name"
						    <?php if ($this->me->userid && !$this->category->allow_anonymous): ?>style="display:none;"<?php endif; ?>>
							<td class="kcol-first">
								<strong><?php echo Text::_('COM_KUNENA_GEN_NAME'); ?></strong>
							</td>
							<td class="kcol-mid">
								<input type="text" id="kauthorname" name="authorname" size="35"
								       class="kinputbox postinput required" maxlength="35"
								       value="<?php echo $this->escape($this->message->name); ?>"/>
							</td>
						</tr>
						<?php if ($this->config->askemail && !$this->me->userid) : ?>
							<tr class="krow<?php echo 1 + $this->k ^= 1 ?>">
								<td class="kcol-first"><strong><?php echo Text::_('COM_KUNENA_GEN_EMAIL'); ?></strong>
								</td>
								<td class="kcol-mid">
									<input type="text" id="email" name="email" size="35"
									       class="kinputbox postinput required validate-email" maxlength="35"
									       value="<?php echo !empty($this->message->email) ? $this->escape($this->message->email) : '' ?>"/>
									<br/>
									<?php echo $this->config->showemail == '0' ? Text::_('COM_KUNENA_POST_EMAIL_NEVER') : Text::_('COM_KUNENA_POST_EMAIL_REGISTERED'); ?>
								</td>
							</tr>
						<?php endif; ?>
						<tr id="kpost-subject" class="krow<?php echo 1 + $this->k ^= 1 ?>">
							<td class="kcol-first">
								<strong><?php echo Text::_('COM_KUNENA_GEN_SUBJECT'); ?></strong>
							</td>

							<td class="kcol-mid"><input type="text" class="kinputbox postinput required" name="subject"
							                            id="subject" size="35"
							                            maxlength="<?php echo $this->ktemplate->params->get('SubjectLengthMessage'); ?>"
							                            <?php if (!$this->config->allow_change_subject && $this->message->parent): ?>disabled<?php endif; ?>
							                            value="<?php echo $this->escape($this->message->subject); ?>"
							                            tabindex="1"/>
								<?php if (!$this->config->allow_change_subject && $this->topic->exists()): ?>
									<input type="hidden" name="subject"
									       value="<?php echo $this->escape($this->message->subject); ?>"/>
								<?php endif; ?>
							</td>
						</tr>
						<?php if (!empty($this->topicIcons)) : ?>
							<tr id="kpost-topicicons" class="krow<?php echo 1 + $this->k ^= 1 ?>">
								<td class="kcol-first">
									<strong><?php echo Text::_('COM_KUNENA_GEN_TOPIC_ICON'); ?></strong>
								</td>

								<td class="kcol-mid">
									<div id="iconset_inject" class="controls controls-select">
										<div id="iconset_topic_list">
											<?php foreach ($this->topicIcons as $id => $icon): ?>
											<input type="radio" id="radio<?php echo $icon->id ?>" name="topic_emoticon"
											       value="<?php echo $icon->id ?>" <?php echo !empty($icon->checked) ? ' checked="checked" ' : '' ?> />
											<?php if ($this->config->topicicons && $topicicontype == 'B2') : ?>
											<label class="radio inline" for="radio<?php echo $icon->id; ?>"><span
														class="icon icon-<?php echo $icon->b2; ?> icon-topic"
														aria-hidden="true"></span>
												<?php elseif ($this->config->topicicons && $topicicontype == 'fa') : ?>
												<label class="radio inline" for="radio<?php echo $icon->id; ?>"><i
															class="fa fa-<?php echo $icon->fa; ?> glyphicon-topic fa-2x"></i>
													<?php else : ?>
													<label class="radio inline" for="radio<?php echo $icon->id; ?>"><img
																src="<?php echo $icon->relpath; ?>" alt="" border="0"/>
														<?php endif; ?>
													</label>
													<?php endforeach; ?>
										</div>
									</div>
								</td>
							</tr>
						<?php endif; ?>
						<?php if ($editor == 1)
						{
							echo $this->subLayout('Widget/Editor')->setLayout('wysibb')->set('message', $this->message)->set('config', $this->config);
						}
						else
						{
							echo $this->subLayout('Widget/Editor')->setLayout('bbcode')->set('message', $this->message)->set('config', $this->config)->set('poll', $this->message->getTopic()->getPoll())->set('allow_polls', $this->topic->getCategory()->allow_polls);
						} ?>

						<?php if ($this->message->exists() && $this->config->editmarkup) : ?>
							<tr>
								<td class="kcol-first" id="modified_reason">
									<label class="control-label"><?php echo Text::_('COM_KUNENA_EDITING_REASON') ?></label>
								</td>
								<td class="kcol-mid">
									<input class="kinputbox postinput" name="modified_reason" maxlength="200" size="35"
									       type="text"
									       value="<?php echo $this->message->modified_reason; ?>" title="reason"/>
								</td>
							</tr>

						<?php endif; ?>
						<?php if ($this->allowedExtensions) : ?>
							<tr id="kpost-attachments" class="krow<?php echo 1 + $this->k ^= 1; ?>">
								<td class="kcol-first">
									<strong><?php echo Text::_('COM_KUNENA_EDITOR_ATTACHMENTS') ?></strong>
								</td>
								<td class="kcol-mid">
									<div id="kattachment-id" class="kattachment">
										<button class="kbutton" id="kshow_attach_form"
										        type="button"><?php echo KunenaIcons::attach() . ' ' . Text::_('COM_KUNENA_EDITOR_ATTACHMENTS'); ?></button>
										<div id="kattach_form" style="display: none;"><br/>
											<span class="label label-info"><?php echo Text::_('COM_KUNENA_FILE_EXTENSIONS_ALLOWED') ?>
												: <?php echo $this->escape(implode(', ', $this->allowedExtensions)) ?></span><br/><br/>
											<span class="label label-info"><?php echo Text::_('COM_KUNENA_UPLOAD_MAX_FILES_WEIGHT') ?>
												: <?php echo $this->config->filesize != 0 ? round($this->config->filesize / 1024, 1) : $this->config->filesize ?> <?php echo Text::_('COM_KUNENA_UPLOAD_ATTACHMENT_FILE_WEIGHT_MB') ?> <?php echo Text::_('COM_KUNENA_UPLOAD_MAX_IMAGES_WEIGHT') ?>
												: <?php echo $this->config->imagesize != 0 ? round($this->config->imagesize / 1024, 1) : $this->config->imagesize ?> <?php echo Text::_('COM_KUNENA_UPLOAD_ATTACHMENT_FILE_WEIGHT_MB') ?></span><br/><br/>
											<!-- The fileinput-button span is used to style the file input field as button -->
											<span class="kbutton fileinput-button">
											<?php echo KunenaIcons::plus(); ?>
												<span><?php echo Text::_('COM_KUNENA_UPLOADED_LABEL_ADD_FILES_BUTTON') ?></span>
												<!-- The file input field used as target for the file upload widget -->
											<input id="fileupload" type="file" name="file" multiple>
										</span>
											<button id="insert-all" class="kbutton" type="submit"
											        style="display:none">
												<?php echo KunenaIcons::upload(); ?>
												<span><?php echo Text::_('COM_KUNENA_UPLOADED_LABEL_INSERT_ALL_BUTTON') ?></span>
											</button>
											<button id="remove-all" class="kbutton btn-outline-danger" type="submit"
											        style="display:none">
												<?php echo KunenaIcons::cancel(); ?>
												<span><?php echo Text::_('COM_KUNENA_UPLOADED_LABEL_REMOVE_ALL_BUTTON') ?></span>
											</button>
											<!-- The container for the uploaded files -->
											<div id="files" class="files"></div>
											<div id="dropzone">
												<div class="dropzone">
													<div class="default message">
														<span id="klabel_info_drop_browse"><?php echo Text::_('COM_KUNENA_UPLOADED_LABEL_DRAG_AND_DROP_OR_BROWSE') ?></span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</td>
							</tr>
						<?php endif; ?>
						<?php if ($this->canSubscribe) : ?>
							<tr id="kpost-subscribe" class="krow<?php echo 1 + $this->k ^= 1; ?>">
								<td class="kcol-first">
									<strong><?php echo Text::_('COM_KUNENA_POST_SUBSCRIBE'); ?></strong>
								</td>
								<td class="kcol-mid">
									<input style="float: left; margin-right: 10px;" type="checkbox" name="subscribeMe"
									       id="subscribeMe"
									       value="1" <?php if ($this->subscriptionschecked == 1 && $this->me->canSubscribe != 0 || $this->subscriptionschecked == 0 && $this->me->canSubscribe == 1)
									{
										echo 'checked="checked"';
									} ?> />
									<label for="subscribeMe"><i><?php echo Text::_('COM_KUNENA_POST_NOTIFIED'); ?></i></label>
								</td>
							</tr>
						<?php endif; ?>
						<?php if (!empty($this->captchaEnabled)) : ?>
							<tr class="control-group">
								<?php echo $this->captchaDisplay; ?>
							</tr>
						<?php endif; ?>
						<tr id="kpost-buttons" class="krow1">
							<td id="kpost-buttons" colspan="2">
								<input type="submit" name="ksubmit" class="kbutton"
								       value="<?php echo(' ' . Text::_('COM_KUNENA_SUBMIT') . ' '); ?>"
								       title="<?php echo(Text::_('COM_KUNENA_EDITOR_HELPLINE_SUBMIT')); ?>"
								       tabindex="4"/>
								<input type="button" name="cancel" class="kbutton"
								       value="<?php echo(' ' . Text::_('COM_KUNENA_CANCEL') . ' '); ?>"
								       onclick="window.history.back();"
								       title="<?php echo(Text::_('COM_KUNENA_EDITOR_HELPLINE_CANCEL')); ?>"
								       tabindex="5"/>
							</td>
						</tr>
						</tbody>
					</table>
				</div>
			</div>
			<?php
			if (!$this->message->name)
			{
				echo '<script type="text/javascript">document.postform.authorname.focus();</script>';
			}
			else
			{
				if (!$this->topic->subject)
				{
					if ($this->config->allow_change_subject)
					{
						echo '<script type="text/javascript">document.postform.subject.focus();</script>';
					}
				}
				else
				{
					echo '<script type="text/javascript">document.postform.message.focus();</script>';
				}
			}
			?>
			<div id="kattach-list"></div>
		</div>
	</form>
<?php
if ($this->config->showhistory && $this->topic->exists())
{
	echo $this->subRequest('Topic/Form/History', new JInput(array('id' => $this->topic->id)));
}
