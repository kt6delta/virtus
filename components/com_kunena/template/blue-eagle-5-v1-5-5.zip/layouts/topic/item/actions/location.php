<?php
/**
 * Kunena Component
 *
 * @package         Kunena.Template.BlueEagle5
 * @subpackage      Layout.Topic
 *
 * @copyright   (C) 2008 - 2020 Kunena Team. All rights reserved.
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            https://www.kunena.org
 **/
defined('_JEXEC') or die;

if ($this->location == 'top')
{
	$goto = '<a id="forumtop"> </a>
				<a href="#forumbottom">
					' . KunenaIcons::arrowdownanchor() . '
				</a>';
}
else
{
	$goto = '<a id="forumbottom"> </a>
				<a href="#forumtop">
					' . KunenaIcons::arrowupanchor() . '
				</a>';
}
?>

<td class="klist-actions-goto center">
	<?php echo $goto ?>
</td>
