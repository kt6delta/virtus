<?php
/**
 * Kunena Component
 *
 * @package         Kunena.Template.BlueEagle5
 * @subpackage      Layout.Widget
 *
 * @copyright   (C) 2008 - 2020 Kunena Team. All rights reserved.
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            https://www.kunena.org
 **/
defined('_JEXEC') or die;

$pathway  = $this->breadcrumb->getPathway();
$item     = array_shift($pathway);
$position = 2;

if ($item)
	:
	?>
	<div class="kblock kpathway breadcrumbs-<?php echo $position; ?>">
		<div class="kcontainer">
			<div class="ksectionbody">
				<div class="kforum-pathway">
					<div class="path-element-first"><a href="<?php echo $item->link ?>"><?php echo $this->escape($item->name) ?></a>
					</div>
					<?php foreach ($pathway as $item) : ?>
						<div class="path-element"><a href="<?php echo $item->link ?>"><?php echo $this->escape($item->name) ?></a>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
<?php endif;

