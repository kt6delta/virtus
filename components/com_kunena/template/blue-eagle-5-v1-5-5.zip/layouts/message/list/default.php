<?php
/**
 * Kunena Component
 *
 * @package         Kunena.Template.BlueEagle5
 * @subpackage      Layout.Message
 *
 * @copyright   (C) 2008 - 2020 Kunena Team. All rights reserved.
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            https://www.kunena.org
 **/
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

$colspan         = !empty($this->actions) ? 4 : 3;
$cols            = empty($this->checkbox) ? 4 : 5;
$view            = Factory::getApplication()->input->getWord('view');
$this->ktemplate = KunenaFactory::getTemplate();
$kcount          = 0;

?>

<table class="klist-actions">
	<tr>
		<td class="klist-actions-info-all">
			<strong>
				<?php echo Text::sprintf($this->messagemore, $this->formatLargeNumber($this->pagination->total)); ?>
			</strong>
		</td>

		<td class="klist-times-all">
			<form action="<?php echo $this->escape(Uri::getInstance()->toString()); ?>"
			      id="timeselect" name="timeselect"
			      method="post" target="_self" class="form-inline hidden-phone">
					<?php $this->displayTimeFilter('sel'); ?>
				<?php echo HTMLHelper::_('form.token'); ?>
			</form>
		</td>

		<td class="klist-search">
				<?php echo $this->subLayout('Widget/Search')
					->set('catid', 'all')
					->setLayout('topic'); ?>
		</td>

		<td class="klist-pages-all"><?php echo $this->subLayout('Widget/Pagination/List')
				->set('pagination', $this->pagination->setDisplayedPages(4))
				->set('display', true); ?></td>
	</tr>
</table>

<div class="kblock kflat">
	<div class="kheader">
		<?php if (!empty($this->topicActions)) : ?>
			<span class="kcheckbox select-toggle"><input class="kcheckall" type="checkbox" name="toggle"
			                                             value=""/></span>
		<?php endif; ?>
		<h2><span><?php echo $this->escape($this->headerText); ?></span></h2>
	</div>
	<div class="kcontainer">
		<div class="kbody">
			<form action="<?php echo KunenaRoute::_('index.php?option=com_kunena&view=topics'); ?>" method="post"
			      name="ktopicsform" id="ktopicsform">
				<?php echo HTMLHelper::_('form.token'); ?>

				<table class="kblocktable" id="kflattable">
					<thead>
					<?php if (empty($this->messages))
						:
						?>
						<tr>
							<td colspan="<?php echo $colspan; ?>">
								<?php echo Text::_('COM_KUNENA_NO_POSTS') ?>
							</td>
						</tr>
					<?php else
						:
						?>
						<tr class="category topic-list-tr">
							<td class="span1 center hidden-phone">
								<a id="forumtop"> </a>
								<a href="#forumbottom">
									<?php echo KunenaIcons::arrowdown(); ?>
								</a>
							</td>
							<td class="span<?php echo $cols; ?>">
								<?php echo Text::_('COM_KUNENA_GEN_MESSAGE'); ?>
								/ <?php echo Text::_('COM_KUNENA_GEN_SUBJECT'); ?>
							</td>
							<td class="span2 hidden-phone">
								<?php echo Text::_('COM_KUNENA_GEN_REPLIES'); ?> / <?php echo Text::_('COM_KUNENA_GEN_HITS'); ?>
							</td>
							<td class="span3">
								<?php echo Text::_('COM_KUNENA_GEN_LAST_POST'); ?>
							</td>
							<?php if (!empty($this->actions))
								:
								?>
								<td class="span1 center">
									<label>
										<input class="kcheckall" type="checkbox" name="toggle" value=""/>
									</label>
								</td>
							<?php endif; ?>
						</tr>
					<?php endif; ?>
					</thead>
					<tfoot>
					<?php if (!empty($this->messages))
						:
						?>
						<tr class="topic-list-tr">
							<td class="center hidden-phone">
								<a id="forumbottom"> </a>
								<a href="#forumtop" rel="nofollow">
									<?php echo KunenaIcons::arrowup(); ?>
								</a>
							</td>
							<td colspan="<?php echo $colspan; ?>">
								<div class="input-append">
									<?php if (!empty($this->moreUri))
									{
										echo HTMLHelper::_('kunenaforum.link', $this->moreUri, Text::_('COM_KUNENA_MORE'), null, 'btn btn-primary', 'nofollow');
									} ?>
									<?php
									if (!empty($this->actions))
										:
										?>
										<?php echo HTMLHelper::_('select.genericlist', $this->actions, 'task', 'class="inputbox kchecktask" ', 'value', 'text', 0, 'kchecktask'); ?>
										<?php
										if (isset($this->actions['move']))
											:
											$options = array(HTMLHelper::_('select.option', '0', Text::_('COM_KUNENA_BULK_CHOOSE_DESTINATION')));
											echo HTMLHelper::_('kunenaforum.categorylist', 'target', 0, $options, array(), 'class="inputbox fbs" disabled="disabled"', 'value', 'text', 0, 'kchecktarget');
										endif; ?>
										<input type="submit" name="kcheckgo" class="btn"
										       value="<?php echo Text::_('COM_KUNENA_GO') ?>"/>
									<?php endif; ?>
								</div>
							</td>
						</tr>
					<?php endif; ?>
					</tfoot>

					<tbody class="message-list">
					<?php
					$counter = 2;
					foreach ($this->messages as $i => $message)
					{
						$count = $kcount++ % 2 ? 1 : 2;
						echo $this->subLayout('Message/Row')
							->set('message', $message)
							->set('row', $count)
							->set('position', $i)
							->set('checkbox', !empty($this->actions));

						if ($this->ktemplate->params->get('displayModule'))
						{
							echo $this->subLayout('Widget/Module')
								->set('position', 'kunena_topic_' . $counter++)
								->set('cols', $cols)
								->setLayout('table_row');
						}
					}
					?>
					</tbody>
				</table>
			</form>
		</div>
	</div>
</div>

<div class="pull-left">
	<?php echo $this->subLayout('Widget/Pagination/List')->set('pagination', $this->pagination->setDisplayedPages(4))->set('display', true); ?>
</div>

<?php if ($view != 'user') : ?>
	<form action="<?php echo $this->escape(Uri::getInstance()->toString()); ?>" id="timeselect" name="timeselect"
	      method="post" target="_self" class="timefilter pull-right">
		<?php $this->displayTimeFilter('sel'); ?>
	</form>
<?php endif; ?>

<div class="clearfix"></div>
