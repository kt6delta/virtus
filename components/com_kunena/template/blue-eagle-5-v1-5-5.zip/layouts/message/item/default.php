<?php
/**
 * Kunena Component
 *
 * @package         Kunena.Template.BlueEagle5
 * @subpackage      Layout.Message
 *
 * @copyright   (C) 2008 - 2020 Kunena Team. All rights reserved.
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            https://www.kunena.org
 **/
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\Registry\Registry;

// @var KunenaForumMessage $message
$category             = $this->message->getCategory();
$message              = $this->message;
$isReply              = $this->message->id != $this->topic->first_post_id;
$signature            = $this->profile->getSignature();
$attachments          = $message->getAttachments();
$attachs              = $message->getNbAttachments();
$avatarname           = $this->profile->getname();
$config               = KunenaConfig::getInstance();
$subjectlengthmessage = $this->ktemplate->params->get('SubjectLengthMessage', 20);
$me                   = KunenaUserHelper::getMyself();
$canDoCaptcha         = KunenaUser::getInstance()->canDoCaptcha();
$template             = KunenaTemplate::getInstance();

if (PluginHelper::isEnabled('captcha'))
{
	$plugin = PluginHelper::getPlugin('captcha');
	$params = new Registry($plugin[0]->params);

	$captcha_pubkey = $params->get('public_key');
	$catcha_privkey = $params->get('private_key');

	if (!empty($captcha_pubkey) && !empty($catcha_privkey))
	{
		PluginHelper::importPlugin('captcha');
		$dispatcher                = JDispatcher::getInstance();
		$result                    = $dispatcher->trigger('onInit', 'dynamic_recaptcha_' . $this->message->id);
		$output                    = $dispatcher->trigger('onDisplay', array(null, 'dynamic_recaptcha_' . $this->message->id,
			'class="controls g-recaptcha" data-sitekey="' . $captcha_pubkey . '" data-theme="light"'));
		$this->quickcaptchaDisplay = $output[0];
		$this->quickcaptchaEnabled = $result[0];
	}
}

if ($config->ordering_system == 'mesid')
{
	$this->numLink = $this->location;
}
else
{
	$this->numLink = $message->replynum;
}

$list = array();
?>

<div class="kmsgbody">
	<div class="kmsgtex">
		<?php if (!$this->me->userid && !$isReply) :
			echo $message->displayField('message');
		else:
			echo (!$this->me->userid && $this->config->teaser) ? Text::_('COM_KUNENA_TEASER_TEXT') : $this->message->displayField('message');
		endif; ?>
	</div>
</div>
<?php if ($signature) : ?>
	<div class="kmsgsignature">
		<div><?php echo $signature ?></div>
	</div>
<?php endif ?>
<?php if (!empty($attachments)) : ?>
	<div class="kmsgattach">
		<h5 style="display: none;"> <?php echo Text::_('COM_KUNENA_ATTACHMENTS'); ?> </h5>
		<ul class="thumbnails">
			<?php foreach ($attachments as $attachment) : 
				if (!$attachment->inline) :?>
					<?php if ($attachment->isAudio()) :
						echo $attachment->getLayout()->render('audio'); ?>
					<?php elseif ($attachment->isVideo()) :
						echo $attachment->getLayout()->render('video'); ?>
					<?php else : ?>
						<li class="span3 center">
							<div class="thumbnail">
								<?php echo $attachment->getLayout()->render('thumbnail'); ?>
								<?php echo $attachment->getLayout()->render('textlink'); ?>
							</div>
						</li>
					<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; ?>
		</ul>
	</div>
<?php elseif ($attachs->total > 0 && !$this->me->exists()):
	if ($attachs->image > 0 && !$this->config->showimgforguest)
	{
		if ($attachs->image > 1)
		{
			echo KunenaLayout::factory('BBCode/Image')->set('title', Text::_('COM_KUNENA_SHOWIMGFORGUEST_HIDEIMG_MULTIPLES'))->setLayout('unauthorised');
		}
		else
		{
			echo KunenaLayout::factory('BBCode/Image')->set('title', Text::_('COM_KUNENA_SHOWIMGFORGUEST_HIDEIMG_SIMPLE'))->setLayout('unauthorised');
		}
	}

	if ($attachs->file > 0 && !$this->config->showfileforguest)
	{
		if ($attachs->file > 1)
		{
			echo KunenaLayout::factory('BBCode/Image')->set('title', Text::_('COM_KUNENA_SHOWIMGFORGUEST_HIDEFILE_MULTIPLES'))->setLayout('unauthorised');
		}
		else
		{
			echo KunenaLayout::factory('BBCode/Image')->set('title', Text::_('COM_KUNENA_SHOWIMGFORGUEST_HIDEFILE_SIMPLE'))->setLayout('unauthorised');
		}
	}
endif; ?>

<?php if (!empty($this->thankyou)) : ?>
	<div class="kmessage-thankyou">
		<?php
		foreach ($this->thankyou as $userid => $thank)
		{
			if (!empty($this->thankyou_delete[$userid]))
			{
				$list[] = $thank . ' <a title="' . Text::_('COM_KUNENA_BUTTON_THANKYOU_REMOVE_LONG') . '" href="'
					. $this->thankyou_delete[$userid] . '">' . KunenaIcons::delete() . '</a>';
			}
			else
			{
				$list[] = $thank;
			}
		}

		echo Text::_('COM_KUNENA_THANKYOU') . ': ' . implode(', ', $list) . ' ';
		if ($this->more_thankyou)
		{
			echo Text::sprintf('COM_KUNENA_THANKYOU_MORE_USERS', $this->more_thankyou);
		}
		?>
	</div>
<?php endif; ?>
