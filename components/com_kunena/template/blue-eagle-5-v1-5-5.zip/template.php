<?php
/**
 * Kunena Component
 *
 * @package         Kunena.Template.BlueEagle5
 * @subpackage      Template
 *
 * @copyright   (C) 2008 - 2020 Kunena Team. All rights reserved.
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            https://www.kunena.org
 **/
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;

/**
 * Blue Eagle 5 template.
 *
 * @since  K5.0
 */
class KunenaTemplateBlue_Eagle5 extends KunenaTemplate
{
	/**
	 * List of parent template names.
	 *
	 * This template will automatically search for missing files from listed parent templates.
	 * The feature allows you to create one base template and only override changed files.
	 *
	 * @var array
	 * @since K5.0
	 */
	protected $default = array('crypsis');

	/**
	 * Template initialization.
	 *
	 * @return void
	 * @since K5.0
	 * @throws Exception
	 */
	public function initialize()
	{
		KunenaTemplate::getInstance()->loadLanguage();
		$ktemplate = KunenaFactory::getTemplate();

		// Template requires Bootstrap javascript
		HTMLHelper::_('bootstrap.framework');

		// Template also requires jQuery framework.
		HTMLHelper::_('jquery.framework');

		if ($ktemplate->params->get('bootstrap'))
		{
			HTMLHelper::_('stylesheet', 'media/jui/css/bootstrap.min.css');
			HTMLHelper::_('stylesheet', 'media/jui/css/bootstrap-responsive.min.css');
			HTMLHelper::_('stylesheet', 'media/jui/css/bootstrap-extended.css');
		}

		// Load JavaScript.
		$this->addScript('assets/js/main.js');

		$storage = $ktemplate->params->get('storage');

		if ($storage)
		{
			$this->addScript('assets/js/localstorage.js');
		}

		// Compile CSS from LESS files.
		$this->compileLess('assets/less/blue_eagle5.less', 'kunena.css');
		$this->addLessSheet('kunena.css');

		$filename = JPATH_SITE . '/components/com_kunena/template/blue_eagle5/assets/css/custom.css';

		if (file_exists($filename) && filesize($filename) != 0)
		{
			$this->addLessSheet('assets/css/custom.css');
		}

		$bootstrap = $ktemplate->params->get('bootstrap');

		if ($bootstrap)
		{
			$this->addStyleSheet(Uri::base() . 'media/jui/css/bootstrap.min.css');
			$this->addStyleSheet(Uri::base() . 'media/jui/css/bootstrap-extended.css');
			$this->addStyleSheet(Uri::base() . 'media/jui/css/bootstrap-responsive.min.css');

			if ($ktemplate->params->get('icomoon'))
			{
				$this->addStyleSheet(Uri::base() . 'media/jui/css/icomoon.css');
			}
		}

		$fontawesome = $ktemplate->params->get('fontawesome');

		if ($fontawesome)
		{
			$this->addScript('https://use.fontawesome.com/releases/v5.15.1/js/all.js', array(), array('defer' => true));
			$this->addScript('https://use.fontawesome.com/releases/v5.15.1/js/v4-shims.js', array(), array('defer' => true));
		}

		// Load template colors settings
		$skinner = $ktemplate->params->get('enableSkinner');
		$styles  = <<<EOF
		/* Kunena Custom CSS */
EOF;

		$IconColor = $ktemplate->params->get('IconColor');

		if ($IconColor)
		{
			$styles .= <<<EOF
	.layout#kunena .kcol-ktopicicon a:link,
	.layout#kunena .kcol-ktopicicon a:visited,
	.layout#kunena .kcol-ktopicicon a:active {color: {$IconColor};}
	.layout#kunena .kcol-ktopicicon a:focus {outline: none;}
	.layout#kunena .kcol-ktopicicon a:hover {color: #FF0000;}
	.layout#kunena .fa-big, .layout#kunena .icon-big {color: {$IconColor};height:32px}
EOF;
		}

		$IconColorNew = $ktemplate->params->get('IconColorNew');

		if ($IconColorNew)
		{
			$styles .= <<<EOF
			.layout#kunena .knewchar {color: {$IconColorNew};}
EOF;
		}

		$forumHeader = $ktemplate->params->get('forumHeadercolor', $skinner ? '' : '#5388B4');

		if ($forumHeader)
		{
			$styles .= <<<EOF

	.layout#kunena div.kblock > div.kheader,.layout#kunena .kblock div.kheader { background: {$forumHeader} !important; }
	.layout#kunena #ktop { border-color: {$forumHeader}; }
	.layout#kunena #ktop span.ktoggler { background: {$forumHeader}; }
	.layout#kunena #ktab li.Kunena-item-active a	{ background-color: {$forumHeader}; }
	.layout#kunena #ktab ul.menu li.active a { background-color: {$forumHeader}; }
	.layout#kunena .kcol-ktopicicon a:link,
	.layout#kunena .kcol-ktopicicon a:visited,
	.layout#kunena .kcol-ktopicicon a:active {color: {$forumHeader};}
	.layout#kunena .kcol-ktopicicon a:focus {outline: none;}
	.layout#kunena .kcol-ktopicicon a:hover {color: #FF0000;}
EOF;
		}

		$topicicontype = $ktemplate->params->get('topicicontype');

		if ($topicicontype == 'image')
		{
			$styles .= <<<EOF
		[class^='icon-'], [class*=' icon-'] {
			background-image: none !important;
		}
EOF;
		}

		$forumLink = $ktemplate->params->get('forumLinkcolor', $skinner ? '' : '#5388B4');

		if ($forumLink)
		{
			$styles .= <<<EOF
	.layout#kunena a:link,
	.layout#kunena a:visited,
	.layout#kunena a:active {color: {$forumLink};}
	.layout#kunena a:focus {outline: none;}
EOF;
		}

		$announcementHeader = $ktemplate->params->get('announcementHeadercolor', $skinner ? '' : '#5388B4');

		if ($announcementHeader)
		{
			$styles .= <<<EOF
	.layout#kunena div.kannouncement div.kheader { background: {$announcementHeader} !important; }
EOF;
		}

		$announcementBox = $ktemplate->params->get('announcementBoxbgcolor', $skinner ? '' : '#FFFFFF');

		if ($announcementBox)
		{
			$styles .= <<<EOF
	.layout#kunena div#kannouncement .kanndesc { background: {$announcementBox}; }
EOF;
		}

		$frontStatsHeader = $ktemplate->params->get('frontstatsHeadercolor', $skinner ? '' : '#5388B4');

		if ($frontStatsHeader)
		{
			$styles .= <<<EOF
	.layout#kunena div.kfrontstats div.kheader { background: {$frontStatsHeader} !important; }
EOF;
		}

		$onlineHeader = $ktemplate->params->get('whoisonlineHeadercolor', $skinner ? '' : '#5388B4');

		if ($onlineHeader)
		{
			$styles .= <<<EOF
	.layout#kunena div.kwhoisonline div.kheader { background: {$onlineHeader} !important; }
EOF;
		}

		$inactiveTab = $ktemplate->params->get('inactiveTabcolor', $skinner ? '' : '#737373');

		if ($inactiveTab)
		{
			$styles .= <<<EOF
	.layout#kunena #ktab a { background-color: {$inactiveTab} !important; }
EOF;
		}

		$activeTab = $ktemplate->params->get('activeTabcolor', $skinner ? '' : '#5388B4');

		if ($activeTab)
		{
			$styles .= <<<EOF
	.layout#kunena #ktab ul.menu li.active a,.layout#kunena #ktab li#current.selected a { background-color: {$activeTab} !important; }
EOF;
		}

		$hoverTab = $ktemplate->params->get('hoverTabcolor', $skinner ? '' : '#5388B4');

		if ($hoverTab)
		{
			$styles .= <<<EOF
	.layout#kunena #ktab a:hover { background-color: {$hoverTab} !important; }
EOF;
		}

		$topBorder = $ktemplate->params->get('topBordercolor', $skinner ? '' : '#5388B4');

		if ($topBorder)
		{
			$styles .= <<<EOF
	.layout#kunena #ktop { border-color: {$topBorder} !important; }
EOF;
		}

		$inactiveFont = $ktemplate->params->get('inactiveFontcolor', $skinner ? '' : '#FFFFFF');

		if ($inactiveFont)
		{
			$styles .= <<<EOF
	.layout#kunena #ktab a span { color: {$inactiveFont} !important; }
EOF;
		}

		$activeFont = $ktemplate->params->get('activeFontcolor', $skinner ? '' : '#FFFFFF');

		if ($activeFont)
		{
			$styles .= <<<EOF
	.layout#kunena #ktab #current a span { color: {$activeFont} !important; }
EOF;
		}

		$toggleButton = $ktemplate->params->get('toggleButtoncolor', $skinner ? '' : '#5388B4');

		if ($toggleButton)
		{
			$styles .= <<<EOF
	.layout#kunena #ktop span.ktoggler { background-color: {$toggleButton} !important; }
EOF;
		}

		$this->addStyleDeclaration($styles);

		parent::initialize();
	}
}
